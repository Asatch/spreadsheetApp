function CEILING(NUMBER) {
  return -(Math.floor(-(NUMBER)));
}
