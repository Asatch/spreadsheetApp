function sc_num_gte(a, b) { return (!isFinite(a) || !isFinite(b)) ? NaN : (a >= b); }
function sc_num_lt(a, b) { return (!isFinite(a) || !isFinite(b)) ? NaN : (a < b); }
function sc_if(c, t, f) { return (c === true) ? t : (c === false) ? f : NaN; }
function sc_num_eq(a, b) { return (!isFinite(a) || !isFinite(b)) ? NaN : (a === b); }

function GCD_MULTI_iteration(prev_A, prev_B, prev_C, VALUES) {
  let var_3 = prev_C;
  let var_5 = (prev_B + 1);
  let var_6 = sc_num_gte(var_5, prev_C);
  let var_11 = (() => {
    let a = sc_if(sc_num_lt(prev_A, 0), -(prev_A), prev_A);
    let b = sc_if(sc_num_lt(VALUES[(var_5) - 1], 0), -(VALUES[(var_5) - 1]), VALUES[(var_5) - 1]);
    if (sc_num_eq(VALUES[(var_5) - 1], 0)) return a;
    while (true) {
      let [new_a, new_b, stop] = GCD_iteration(a, b);
      a = new_a;
      b = new_b;
      if (stop !== false) break;
    }
    return a;
  })();
  return [var_11, var_5, prev_C, var_6];
}


function sc_num_lte(a, b) { return (!isFinite(a) || !isFinite(b)) ? NaN : (a <= b); }

function GCD_iteration(prev_A, prev_B) {
  let var_2 = prev_B;
  let var_3 = (prev_A - (prev_B * Math.floor((prev_A / prev_B))));
  let var_4 = sc_num_lte(var_3, 0);
  return [prev_B, var_3, var_4];
}

function sc_num_lte(a, b) { return (!isFinite(a) || !isFinite(b)) ? NaN : (a <= b); }

function GCD_MULTI(VALUES) {
  return (() => {
    let a = VALUES[0];
    let b = 1;
    let c = (VALUES).length;
    if (sc_num_lte((VALUES).length, 1)) return a;
    while (true) {
      let [new_a, new_b, new_c, stop] = GCD_MULTI_iteration(a, b, c, VALUES);
      a = new_a;
      b = new_b;
      c = new_c;
      if (stop !== false) break;
    }
    return a;
  })();
}
