function LOG10(NUMBER) {
  return (Math.log(NUMBER) / Math.log(10));
}
