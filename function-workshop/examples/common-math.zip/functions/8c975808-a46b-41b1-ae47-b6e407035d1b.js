function sc_num_lt(a, b) { return (!isFinite(a) || !isFinite(b)) ? NaN : (a < b); }
function sc_if(c, t, f) { return (c === true) ? t : (c === false) ? f : NaN; }

function ROUND(NUMBER, NUM_DIGITS) {
  let var_30 = (Math.floor(((sc_if(sc_num_lt(NUMBER, 0), -(NUMBER), NUMBER) * (10 ** NUM_DIGITS)) + 0.5)) / (10 ** NUM_DIGITS));
  let var_39 = (sc_if(sc_num_lt(NUMBER, 0), -1, 1) * var_30);
  return var_39;
}
