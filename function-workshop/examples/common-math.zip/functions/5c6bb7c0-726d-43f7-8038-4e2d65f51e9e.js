function sc_num_eq(a, b) { return (!isFinite(a) || !isFinite(b)) ? NaN : (a === b); }
function sc_num_lt(a, b) { return (!isFinite(a) || !isFinite(b)) ? NaN : (a < b); }
function sc_if(c, t, f) { return (c === true) ? t : (c === false) ? f : NaN; }
function sc_num_gte(a, b) { return (!isFinite(a) || !isFinite(b)) ? NaN : (a >= b); }
function sc_and(arr) { let n = false; for (const v of arr) { if (v === false) return false; if (v !== true) n = true; } return n ? NaN : true; }
function sc_or(arr) { let n = false; for (const v of arr) { if (v === true) return true; if (v !== false) n = true; } return n ? NaN : false; }

function ATAN_iteration(prev_A, prev_B, prev_C, prev_D, TARGET) {
  let var_3 = prev_C;
  let var_4 = prev_D;
  let var_7 = (prev_B + 1);
  let var_10 = (((Math.sin(prev_A) / Math.sin((prev_A + 1.5707963267948966))) - prev_C) / (1 + ((Math.sin(prev_A) / Math.sin((prev_A + 1.5707963267948966))) ** 2)));
  let var_6 = (prev_A - var_10);
  let var_8 = sc_if(sc_num_eq(prev_D, 1), sc_if(sc_num_lt(TARGET, 0), (-1.5707963267948966 - var_6), (1.5707963267948966 - var_6)), var_6);
  let var_24 = [sc_and([sc_num_gte(var_7, 2), sc_num_lt(((var_6 - prev_A) * (var_6 - prev_A)), 1e-12)]), sc_num_gte(var_7, 20)];
  let var_9 = sc_or(var_24);
  return [var_6, var_7, prev_C, prev_D, var_8, var_9];
}

function sc_num_lt(a, b) { return (!isFinite(a) || !isFinite(b)) ? NaN : (a < b); }
function sc_if(c, t, f) { return (c === true) ? t : (c === false) ? f : NaN; }
function sc_num_gt(a, b) { return (!isFinite(a) || !isFinite(b)) ? NaN : (a > b); }

function ATAN(TARGET) {
  let var_7 = sc_num_gt(sc_if(sc_num_lt(TARGET, 0), -(TARGET), TARGET), 1);
  return (() => {
    let a = sc_if(var_7, (1 / TARGET), TARGET);
    let b = 0;
    let c = sc_if(var_7, (1 / TARGET), TARGET);
    let d = sc_if(var_7, 1, 0);
    let e = sc_if(var_7, (1 / TARGET), TARGET);
    while (true) {
      let [new_a, new_b, new_c, new_d, new_e, stop] = ATAN_iteration(a, b, c, d, TARGET);
      a = new_a;
      b = new_b;
      c = new_c;
      d = new_d;
      e = new_e;
      if (stop !== false) break;
    }
    return e;
  })();
}
