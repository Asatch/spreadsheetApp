function COS(X) {
  return Math.sin((X + 1.5707963267948966));
}
