function sc_num_lte(a, b) { return (!isFinite(a) || !isFinite(b)) ? NaN : (a <= b); }

function GCD_iteration(prev_A, prev_B) {
  let var_2 = prev_B;
  let var_3 = (prev_A - (prev_B * Math.floor((prev_A / prev_B))));
  let var_4 = sc_num_lte(var_3, 0);
  return [prev_B, var_3, var_4];
}

function sc_num_lt(a, b) { return (!isFinite(a) || !isFinite(b)) ? NaN : (a < b); }
function sc_if(c, t, f) { return (c === true) ? t : (c === false) ? f : NaN; }
function sc_num_eq(a, b) { return (!isFinite(a) || !isFinite(b)) ? NaN : (a === b); }

function LCM(NUM1, NUM2) {
  let var_35 = (() => {
    let a = sc_if(sc_num_lt(NUM1, 0), -(NUM1), NUM1);
    let b = sc_if(sc_num_lt(NUM2, 0), -(NUM2), NUM2);
    if (sc_num_eq(NUM2, 0)) return a;
    while (true) {
      let [new_a, new_b, stop] = GCD_iteration(a, b);
      a = new_a;
      b = new_b;
      if (stop !== false) break;
    }
    return a;
  })();
  let var_23 = sc_if(sc_num_eq(var_35, 0), 0, (sc_if(sc_num_lt((NUM1 * NUM2), 0), -((NUM1 * NUM2)), (NUM1 * NUM2)) / var_35));
  return var_23;
}
