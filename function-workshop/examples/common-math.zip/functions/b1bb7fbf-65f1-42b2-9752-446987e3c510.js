function DEGREES(RADIANS) {
  return (RADIANS * (180 / (3.141592653589793 * 1)));
}
