function sc_num_gte(a, b) { return (!isFinite(a) || !isFinite(b)) ? NaN : (a >= b); }
function sc_num_lt(a, b) { return (!isFinite(a) || !isFinite(b)) ? NaN : (a < b); }
function sc_and(arr) { let n = false; for (const v of arr) { if (v === false) return false; if (v !== true) n = true; } return n ? NaN : true; }

function ACOS_iteration(prev_A, prev_B, TARGET) {
  let var_5 = (prev_B + 1);
  let var_4 = (prev_A + ((Math.sin((prev_A + 1.5707963267948966)) - TARGET) / Math.sin(prev_A)));
  let var_6 = sc_and([sc_num_gte(var_5, 2), sc_num_lt(((var_4 - prev_A) * (var_4 - prev_A)), 1e-12)]);
  return [var_4, var_5, var_6];
}

function ACOS(TARGET) {
  return (() => {
    let a = 1.5707963267948966;
    let b = 0;
    while (true) {
      let [new_a, new_b, stop] = ACOS_iteration(a, b, TARGET);
      a = new_a;
      b = new_b;
      if (stop !== false) break;
    }
    return a;
  })();
}
