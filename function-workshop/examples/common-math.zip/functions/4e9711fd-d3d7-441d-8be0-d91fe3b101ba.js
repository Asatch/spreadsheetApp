function LOG(NUMBER, BASE) {
  return (Math.log(NUMBER) / Math.log(BASE));
}
