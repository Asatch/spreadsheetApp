function sc_num_lt(a, b) { return (!isFinite(a) || !isFinite(b)) ? NaN : (a < b); }
function sc_if(c, t, f) { return (c === true) ? t : (c === false) ? f : NaN; }

function ABS(NUMBER) {
  return sc_if(sc_num_lt(NUMBER, 0), -(NUMBER), NUMBER);
}
