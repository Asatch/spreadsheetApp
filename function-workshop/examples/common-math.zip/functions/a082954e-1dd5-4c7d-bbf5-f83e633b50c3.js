function sc_num_gte(a, b) { return (!isFinite(a) || !isFinite(b)) ? NaN : (a >= b); }

function AVERAGE_iteration(prev_A, prev_B, VALUES) {
  let var_4 = (prev_B + 1);
  let var_7 = sc_num_gte(var_4, (VALUES).length);
  let var_5 = (prev_A + VALUES[(var_4) - 1]);
  let var_6 = (var_5 / (VALUES).length);
  return [var_5, var_4, var_6, var_7];
}

function sc_num_lte(a, b) { return (!isFinite(a) || !isFinite(b)) ? NaN : (a <= b); }

function AVERAGE(VALUES) {
  return (() => {
    let a = 0;
    let b = 0;
    let c = 0;
    if (sc_num_lte((VALUES).length, 0)) return c;
    while (true) {
      let [new_a, new_b, new_c, stop] = AVERAGE_iteration(a, b, VALUES);
      a = new_a;
      b = new_b;
      c = new_c;
      if (stop !== false) break;
    }
    return c;
  })();
}
