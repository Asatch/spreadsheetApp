function SQRT(NUMBER) {
  return (NUMBER ** 0.5);
}
