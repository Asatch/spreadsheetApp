function sc_num_lt(a, b) { return (!isFinite(a) || !isFinite(b)) ? NaN : (a < b); }
function sc_if(c, t, f) { return (c === true) ? t : (c === false) ? f : NaN; }

function ROUNDUP(NUMBER, NUM_DIGITS) {
  let var_56 = Math.floor((sc_if(sc_num_lt(NUMBER, 0), -(NUMBER), NUMBER) * (10 ** NUM_DIGITS)));
  let var_31 = (var_56 + sc_if(sc_num_lt(var_56, (sc_if(sc_num_lt(NUMBER, 0), -(NUMBER), NUMBER) * (10 ** NUM_DIGITS))), 1, 0));
  let var_34 = (var_31 / (10 ** NUM_DIGITS));
  let var_43 = (sc_if(sc_num_lt(NUMBER, 0), -1, 1) * var_34);
  return var_43;
}
