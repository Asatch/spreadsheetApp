function sc_num_gte(a, b) { return (!isFinite(a) || !isFinite(b)) ? NaN : (a >= b); }

function PRODUCT_iteration(prev_A, prev_B, prev_C, VALUES) {
  let var_3 = prev_C;
  let var_5 = (prev_B + 1);
  let var_7 = sc_num_gte(var_5, prev_C);
  let var_6 = (prev_A * VALUES[(var_5) - 1]);
  return [var_6, var_5, prev_C, var_7];
}

function sc_num_lte(a, b) { return (!isFinite(a) || !isFinite(b)) ? NaN : (a <= b); }

function PRODUCT(VALUES) {
  return (() => {
    let a = 1;
    let b = 0;
    let c = (VALUES).length;
    if (sc_num_lte((VALUES).length, 0)) return a;
    while (true) {
      let [new_a, new_b, new_c, stop] = PRODUCT_iteration(a, b, c, VALUES);
      a = new_a;
      b = new_b;
      c = new_c;
      if (stop !== false) break;
    }
    return a;
  })();
}
