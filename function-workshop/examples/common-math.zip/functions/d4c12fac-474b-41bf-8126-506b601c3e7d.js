function RADIANS(DEGREES) {
  return (DEGREES * ((3.141592653589793 * 1) / 180));
}
