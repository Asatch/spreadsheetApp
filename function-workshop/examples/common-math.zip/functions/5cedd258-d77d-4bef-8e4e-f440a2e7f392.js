function TAN(X) {
  return (Math.sin(X) / Math.sin((X + 1.5707963267948966)));
}
