function WITHDRAW_TAXABLE(BALANCE, SHORTFALL, BASIS) {
  let var_28 = (0.15 * ((BALANCE === 0) ? 0 : ((BALANCE - BASIS) / BALANCE)));
  let var_39 = ((BALANCE === 0) ? 0 : Math.min(...[((var_28 === 1) ? SHORTFALL : (SHORTFALL / (1 - var_28))), BALANCE]));
  return { WITHDRAWAL: var_39, TAX: (var_39 * var_28), REMAINING_SHORTFALL: Math.max(...[0, (SHORTFALL - (var_39 - (var_39 * var_28)))]), BASIS_REDUCTION: ((BALANCE === 0) ? 0 : ((var_39 === BALANCE) ? BASIS : (var_39 * (BASIS / BALANCE)))) };
}
