function CUSTOM_ACCOUNT_DIST(BALANCE, YEAR) {
  return ([(YEAR >= 1), (YEAR <= 10)].every(Boolean) ? (BALANCE / ((10 - YEAR) + 1)) : 0);
}
