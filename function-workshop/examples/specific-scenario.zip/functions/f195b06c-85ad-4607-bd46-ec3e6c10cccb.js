function ACCUMULATION_iteration(prev_B, prev_C, prev_D, prev_E, prev_F, prev_G, CUSTOM_SAVINGS, TAXABLE_SAVINGS, TAX_DEFERRED_SAVINGS, TAX_FREE_SAVINGS, RETURN_RATE, INFLATION_RATE, YEARS) {
  let var_19 = (prev_G + 1);
  let var_20 = (var_19 >= YEARS);
  let var_16 = ((prev_D + TAXABLE_SAVINGS) * (1 - INFLATION_RATE));
  let var_14 = ((prev_B * (1 + RETURN_RATE)) + (CUSTOM_SAVINGS * ((1 + RETURN_RATE) ** 0.5)));
  let var_15 = ((prev_C * (1 + RETURN_RATE)) + (TAXABLE_SAVINGS * ((1 + RETURN_RATE) ** 0.5)));
  let var_17 = ((prev_E * (1 + RETURN_RATE)) + (TAX_DEFERRED_SAVINGS * ((1 + RETURN_RATE) ** 0.5)));
  let var_18 = ((prev_F * (1 + RETURN_RATE)) + (TAX_FREE_SAVINGS * ((1 + RETURN_RATE) ** 0.5)));
  return [var_14, var_15, var_16, var_17, var_18, var_19, var_20];
}

function ACCUMULATION(CUSTOM_BALANCE, TAXABLE_BALANCE, TAXABLE_BASIS, TAX_DEFERRED_BALANCE, TAX_FREE_BALANCE, CUSTOM_SAVINGS, TAXABLE_SAVINGS, TAX_DEFERRED_SAVINGS, TAX_FREE_SAVINGS, RETURN_RATE, INFLATION_RATE, YEARS) {
  return (() => {
    let b = CUSTOM_BALANCE;
    let c = TAXABLE_BALANCE;
    let d = TAXABLE_BASIS;
    let e = TAX_DEFERRED_BALANCE;
    let f = TAX_FREE_BALANCE;
    let g = 0;
    if ((YEARS <= 0)) return { ENDING_CUSTOM: b, ENDING_TAXABLE: c, ENDING_BASIS: d, ENDING_TAX_DEFERRED: e, ENDING_TAX_FREE: f };
    while (true) {
      let [new_b, new_c, new_d, new_e, new_f, new_g, stop] = ACCUMULATION_iteration(b, c, d, e, f, g, CUSTOM_SAVINGS, TAXABLE_SAVINGS, TAX_DEFERRED_SAVINGS, TAX_FREE_SAVINGS, RETURN_RATE, INFLATION_RATE, YEARS);
      b = new_b;
      c = new_c;
      d = new_d;
      e = new_e;
      f = new_f;
      g = new_g;
      if (stop) break;
    }
    return { ENDING_CUSTOM: b, ENDING_TAXABLE: c, ENDING_BASIS: d, ENDING_TAX_DEFERRED: e, ENDING_TAX_FREE: f };
  })();
}
