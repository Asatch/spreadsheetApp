function sc_num_lte(a, b) { return (!isFinite(a) || !isFinite(b)) ? NaN : (a <= b); }
function sc_if(c, t, f) { return (c === true) ? t : (c === false) ? f : NaN; }
function sc_num_lt(a, b) { return (!isFinite(a) || !isFinite(b)) ? NaN : (a < b); }
function sc_num_eq(a, b) { return (!isFinite(a) || !isFinite(b)) ? NaN : (a === b); }
function sc_num_gt(a, b) { return (!isFinite(a) || !isFinite(b)) ? NaN : (a > b); }

function YEARFRAC(START_DATE, END_DATE, BASIS) {
  let var_279 = Math.floor(((((END_DATE + 109571.75) / 365.2425) - 300) + 1900));
  let var_265 = Math.floor(((((START_DATE + 109571.75) / 365.2425) - 300) + 1900));
  let var_130 = ((Math.floor(((var_279 - 1) / 4)) - Math.floor(((var_279 - 1) / 100))) + Math.floor(((var_279 - 1) / 400)));
  let var_33 = ((Math.floor(((var_265 - 1) / 4)) - Math.floor(((var_265 - 1) / 100))) + Math.floor(((var_265 - 1) / 400)));
  let var_128 = (var_130 - 459);
  let var_31 = (var_33 - 459);
  let var_125 = sc_if(sc_num_lte(var_279, 1900), 0, var_128);
  let var_28 = sc_if(sc_num_lte(var_265, 1900), 0, var_31);
  let var_123 = (((var_279 - 1900) * 365) + var_125);
  let var_26 = (((var_265 - 1900) * 365) + var_28);
  let var_122 = (var_123 + 1);
  let var_25 = (var_26 + 1);
  let var_144 = (END_DATE - var_122);
  let var_47 = (START_DATE - var_25);
  let var_143 = (var_144 + 1);
  let var_46 = (var_47 + 1);
  let var_142 = sc_num_lt(var_143, 1);
  let var_45 = sc_num_lt(var_46, 1);
  let var_141 = sc_if(var_142, (var_279 - 1), var_279);
  let var_44 = sc_if(var_45, (var_265 - 1), var_265);
  let var_178 = (var_141 - 1);
  let var_87 = (var_44 - 1);
  let var_148 = sc_if(sc_num_eq((var_141 % 400), 0), 1, sc_if(sc_num_eq((var_141 % 100), 0), 0, sc_if(sc_num_eq((var_141 % 4), 0), 1, 0)));
  let var_51 = sc_if(sc_num_eq((var_44 % 400), 0), 1, sc_if(sc_num_eq((var_44 % 100), 0), 0, sc_if(sc_num_eq((var_44 % 4), 0), 1, 0)));
  let var_167 = (((Math.floor((var_178 / 4)) - Math.floor((var_178 / 100))) + Math.floor((var_178 / 400))) - 459);
  let var_146 = sc_if(sc_num_eq(var_141, 1900), 1, var_148);
  let var_76 = (((Math.floor((var_87 / 4)) - Math.floor((var_87 / 100))) + Math.floor((var_87 / 400))) - 459);
  let var_49 = sc_if(sc_num_eq(var_44, 1900), 1, var_51);
  let var_164 = sc_if(sc_num_lte(var_141, 1900), 0, var_167);
  let var_73 = sc_if(sc_num_lte(var_44, 1900), 0, var_76);
  let var_162 = (((var_141 - 1900) * 365) + var_164);
  let var_71 = (((var_44 - 1900) * 365) + var_73);
  let var_161 = (var_162 + 1);
  let var_70 = (var_71 + 1);
  let var_159 = (END_DATE - var_161);
  let var_68 = (START_DATE - var_70);
  let var_158 = (var_159 + 1);
  let var_67 = (var_68 + 1);
  let var_186 = sc_if(sc_num_gt(var_158, 59), var_146, 0);
  let var_183 = (var_158 - var_186);
  let var_92 = (var_67 - sc_if(sc_num_gt(var_67, 59), var_49, 0));
  let var_195 = sc_if(sc_num_lte(var_183, 212), 7, sc_if(sc_num_lte(var_183, 243), 8, sc_if(sc_num_lte(var_183, 273), 9, sc_if(sc_num_lte(var_183, 304), 10, sc_if(sc_num_lte(var_183, 334), 11, 12)))));
  let var_104 = sc_if(sc_num_lte(var_92, 212), 7, sc_if(sc_num_lte(var_92, 243), 8, sc_if(sc_num_lte(var_92, 273), 9, sc_if(sc_num_lte(var_92, 304), 10, sc_if(sc_num_lte(var_92, 334), 11, 12)))));
  let var_193 = sc_if(sc_num_lte(var_183, 181), 6, var_195);
  let var_102 = sc_if(sc_num_lte(var_92, 181), 6, var_104);
  let var_191 = sc_if(sc_num_lte(var_183, 151), 5, var_193);
  let var_100 = sc_if(sc_num_lte(var_92, 151), 5, var_102);
  let var_97 = sc_if(sc_num_lte(var_92, 120), 4, var_100);
  let var_94 = sc_if(sc_num_lte(var_92, 90), 3, var_97);
  let var_91 = sc_if(sc_num_lte(var_92, 59), 2, var_94);
  let var_89 = sc_if(sc_num_lte(var_92, 31), 1, var_91);
  let var_212 = (sc_if(sc_num_lte(var_183, 31), 1, sc_if(sc_num_lte(var_183, 59), 2, sc_if(sc_num_lte(var_183, 90), 3, sc_if(sc_num_lte(var_183, 120), 4, var_191)))) - var_89);
  let var_208 = (var_212 * 30);
  let var_206 = (((var_141 - var_44) * 360) + var_208);
  let var_218 = (var_206 / 360);
  let var_219 = sc_if(sc_num_eq(BASIS, 1), ((END_DATE - START_DATE) / (365 + var_49)), sc_if(sc_num_eq(BASIS, 2), ((END_DATE - START_DATE) / 360), sc_if(sc_num_eq(BASIS, 3), ((END_DATE - START_DATE) / 365), var_218)));
  let var_216 = sc_if(sc_num_eq(BASIS, 0), var_218, var_219);
  return var_216;
}
