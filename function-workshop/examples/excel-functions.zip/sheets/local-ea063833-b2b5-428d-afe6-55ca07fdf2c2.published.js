function sc_num_lt(a, b) { return (!isFinite(a) || !isFinite(b)) ? NaN : (a < b); }
function sc_if(c, t, f) { return (c === true) ? t : (c === false) ? f : NaN; }

function NORMSDIST(Z) {
  let var_75 = sc_if(sc_num_lt(Z, 0), -(Z), Z);
  let var_29 = (1 / (1 + (0.2316419 * var_75)));
  let var_57 = (var_29 * (-0.356563782 + (var_29 * (1.781477937 + (var_29 * (-1.821255978 + (var_29 * 1.330274429)))))));
  let var_56 = (0.31938153 + var_57);
  let var_54 = (var_29 * var_56);
  let var_62 = ((Math.exp(((-(var_75) * var_75) / 2)) / 2.506628274631) * var_54);
  let var_61 = (1 - var_62);
  return sc_if(sc_num_lt(Z, 0), (1 - var_61), var_61);
}
