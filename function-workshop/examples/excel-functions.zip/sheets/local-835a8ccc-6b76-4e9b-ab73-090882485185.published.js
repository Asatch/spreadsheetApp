function sc_num_eq(a, b) { return (!isFinite(a) || !isFinite(b)) ? NaN : (a === b); }
function sc_if(c, t, f) { return (c === true) ? t : (c === false) ? f : NaN; }

function PMT(RATE, NPER, PV, FV, TYPE) {
  let var_56 = ((-(RATE) * ((PV * ((1 + RATE) ** NPER)) + FV)) / ((((1 + RATE) ** NPER) - 1) * sc_if(sc_num_eq(TYPE, 1), (1 + RATE), 1)));
  return var_56;
}
