function sc_num_lte(a, b) { return (!isFinite(a) || !isFinite(b)) ? NaN : (a <= b); }

function FACTORIAL_iteration(prev_A, prev_B) {
  let var_4 = (prev_A * prev_B);
  let var_3 = (prev_A - 1);
  let var_5 = sc_num_lte(var_3, 1);
  return [var_3, var_4, var_5];
}


function sc_num_lte(a, b) { return (!isFinite(a) || !isFinite(b)) ? NaN : (a <= b); }

function FACTORIAL_iteration(prev_A, prev_B) {
  let var_4 = (prev_A * prev_B);
  let var_3 = (prev_A - 1);
  let var_5 = sc_num_lte(var_3, 1);
  return [var_3, var_4, var_5];
}


function sc_num_lte(a, b) { return (!isFinite(a) || !isFinite(b)) ? NaN : (a <= b); }

function FACTORIAL_iteration(prev_A, prev_B) {
  let var_4 = (prev_A * prev_B);
  let var_3 = (prev_A - 1);
  let var_5 = sc_num_lte(var_3, 1);
  return [var_3, var_4, var_5];
}

function sc_num_lte(a, b) { return (!isFinite(a) || !isFinite(b)) ? NaN : (a <= b); }

function COMBIN(N, K) {
  let var_32 = ((() => {
    let a = N;
    let b = 1;
    if (sc_num_lte(N, 0)) return b;
    while (true) {
      let [new_a, new_b, stop] = FACTORIAL_iteration(a, b);
      a = new_a;
      b = new_b;
      if (stop !== false) break;
    }
    return b;
  })() / ((() => {
    let a = K;
    let b = 1;
    if (sc_num_lte(K, 0)) return b;
    while (true) {
      let [new_a, new_b, stop] = FACTORIAL_iteration(a, b);
      a = new_a;
      b = new_b;
      if (stop !== false) break;
    }
    return b;
  })() * (() => {
    let a = (N - K);
    let b = 1;
    if (sc_num_lte((N - K), 0)) return b;
    while (true) {
      let [new_a, new_b, stop] = FACTORIAL_iteration(a, b);
      a = new_a;
      b = new_b;
      if (stop !== false) break;
    }
    return b;
  })()));
  return var_32;
}
