function sc_num_lt(a, b) { return (!isFinite(a) || !isFinite(b)) ? NaN : (a < b); }
function sc_if(c, t, f) { return (c === true) ? t : (c === false) ? f : NaN; }

function TRUNC(NUMBER, NUM_DIGITS) {
  let var_31 = (Math.floor((sc_if(sc_num_lt(NUMBER, 0), -(NUMBER), NUMBER) * (10 ** NUM_DIGITS))) / (10 ** NUM_DIGITS));
  return sc_if(sc_num_lt(NUMBER, 0), -(var_31), var_31);
}
