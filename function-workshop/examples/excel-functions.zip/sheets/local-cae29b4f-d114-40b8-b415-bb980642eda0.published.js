function sc_num_eq(a, b) { return (!isFinite(a) || !isFinite(b)) ? NaN : (a === b); }
function sc_if(c, t, f) { return (c === true) ? t : (c === false) ? f : NaN; }

function PV(RATE, NPER, PMT, FV, TYPE) {
  let var_49 = ((-(PMT) * ((1 - (1 / ((1 + RATE) ** NPER))) / RATE)) * sc_if(sc_num_eq(TYPE, 1), (1 + RATE), 1));
  let var_55 = ((-(FV) / ((1 + RATE) ** NPER)) + var_49);
  return var_55;
}
