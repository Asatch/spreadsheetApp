function SYD(COST, SALVAGE, LIFE, PER) {
  return ((COST - SALVAGE) * (((LIFE - PER) + 1) / ((LIFE * (LIFE + 1)) / 2)));
}
