function sc_num_lt(a, b) { return (!isFinite(a) || !isFinite(b)) ? NaN : (a < b); }
function sc_if(c, t, f) { return (c === true) ? t : (c === false) ? f : NaN; }
function sc_num_eq(a, b) { return (!isFinite(a) || !isFinite(b)) ? NaN : (a === b); }

function ODD(NUMBER) {
  let var_14 = -(Math.floor(-(sc_if(sc_num_lt(NUMBER, 0), -(NUMBER), NUMBER))));
  let var_43 = (sc_if(sc_num_lt(NUMBER, 0), -1, 1) * sc_if(sc_num_eq((var_14 - (Math.floor((var_14 / 2)) * 2)), 0), (var_14 + 1), var_14));
  let var_41 = sc_if(sc_num_eq(NUMBER, 0), 1, var_43);
  return var_41;
}
