function sc_num_lte(a, b) { return (!isFinite(a) || !isFinite(b)) ? NaN : (a <= b); }
function sc_if(c, t, f) { return (c === true) ? t : (c === false) ? f : NaN; }
function sc_num_lt(a, b) { return (!isFinite(a) || !isFinite(b)) ? NaN : (a < b); }

function YEAR(SERIAL) {
  let var_69 = Math.floor(((((SERIAL + 109571.75) / 365.2425) - 300) + 1900));
  let var_27 = (var_69 - 1);
  let var_32 = (((Math.floor((var_27 / 4)) - Math.floor((var_27 / 100))) + Math.floor((var_27 / 400))) - 459);
  let var_30 = sc_if(sc_num_lte(var_69, 1900), 0, var_32);
  let var_44 = (((var_69 - 1900) * 365) + var_30);
  let var_43 = (var_44 + 1);
  let var_48 = (SERIAL - var_43);
  let var_47 = (var_48 + 1);
  let var_53 = sc_num_lt(var_47, 1);
  let var_52 = sc_if(var_53, (var_69 - 1), var_69);
  return var_52;
}
