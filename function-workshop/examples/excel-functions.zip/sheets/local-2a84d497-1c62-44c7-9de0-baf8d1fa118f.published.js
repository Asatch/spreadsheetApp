function SECOND(SERIAL) {
  let var_30 = (((((((SERIAL % 1) * 24) % 1) * 60) % 1) * 60) + 0.0001);
  return Math.floor(var_30);
}
