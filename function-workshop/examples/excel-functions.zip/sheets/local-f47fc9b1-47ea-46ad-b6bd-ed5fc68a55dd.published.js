function sc_num_lte(a, b) { return (!isFinite(a) || !isFinite(b)) ? NaN : (a <= b); }
function sc_if(c, t, f) { return (c === true) ? t : (c === false) ? f : NaN; }
function sc_num_lt(a, b) { return (!isFinite(a) || !isFinite(b)) ? NaN : (a < b); }
function sc_num_eq(a, b) { return (!isFinite(a) || !isFinite(b)) ? NaN : (a === b); }
function sc_num_gt(a, b) { return (!isFinite(a) || !isFinite(b)) ? NaN : (a > b); }

function MONTH(SERIAL) {
  let var_183 = Math.floor(((((SERIAL + 109571.75) / 365.2425) - 300) + 1900));
  let var_46 = (var_183 - 1);
  let var_55 = (((Math.floor((var_46 / 4)) - Math.floor((var_46 / 100))) + Math.floor((var_46 / 400))) - 459);
  let var_52 = sc_if(sc_num_lte(var_183, 1900), 0, var_55);
  let var_50 = (((var_183 - 1900) * 365) + var_52);
  let var_49 = (var_50 + 1);
  let var_68 = (SERIAL - var_49);
  let var_67 = (var_68 + 1);
  let var_72 = sc_num_lt(var_67, 1);
  let var_71 = sc_if(var_72, (var_183 - 1), var_183);
  let var_94 = (var_71 - 1);
  let var_83 = (((Math.floor((var_94 / 4)) - Math.floor((var_94 / 100))) + Math.floor((var_94 / 400))) - 459);
  let var_172 = sc_if(sc_num_eq(sc_if(sc_num_eq((var_71 % 100), 0), 1, 0), 0), 1, sc_if(sc_num_eq(sc_if(sc_num_eq((var_71 % 400), 0), 1, 0), 1), 1, sc_if(sc_num_eq(var_71, 1900), 1, 0)));
  let var_80 = sc_if(sc_num_lte(var_71, 1900), 0, var_83);
  let var_170 = sc_if(sc_num_eq(sc_if(sc_num_eq((var_71 % 4), 0), 1, 0), 0), 0, var_172);
  let var_78 = (((var_71 - 1900) * 365) + var_80);
  let var_77 = (var_78 + 1);
  let var_98 = (SERIAL - var_77);
  let var_97 = (var_98 + 1);
  let var_104 = sc_if(sc_num_gt(var_97, 59), var_170, 0);
  let var_108 = (var_97 - var_104);
  let var_124 = sc_if(sc_num_lte(var_108, 212), 7, sc_if(sc_num_lte(var_108, 243), 8, sc_if(sc_num_lte(var_108, 273), 9, sc_if(sc_num_lte(var_108, 304), 10, sc_if(sc_num_lte(var_108, 334), 11, 12)))));
  let var_122 = sc_if(sc_num_lte(var_108, 181), 6, var_124);
  let var_120 = sc_if(sc_num_lte(var_108, 151), 5, var_122);
  let var_118 = sc_if(sc_num_lte(var_108, 120), 4, var_120);
  let var_116 = sc_if(sc_num_lte(var_108, 90), 3, var_118);
  let var_114 = sc_if(sc_num_lte(var_108, 59), 2, var_116);
  let var_112 = sc_if(sc_num_lte(var_108, 31), 1, var_114);
  return var_112;
}
