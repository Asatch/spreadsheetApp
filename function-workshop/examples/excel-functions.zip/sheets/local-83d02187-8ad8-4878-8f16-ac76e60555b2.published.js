function sc_num_eq(a, b) { return (!isFinite(a) || !isFinite(b)) ? NaN : (a === b); }
function sc_if(c, t, f) { return (c === true) ? t : (c === false) ? f : NaN; }

function ISLEAPYEAR(YEAR) {
  let var_36 = sc_if(sc_num_eq(sc_if(sc_num_eq((YEAR % 100), 0), 1, 0), 0), 1, sc_if(sc_num_eq(sc_if(sc_num_eq((YEAR % 400), 0), 1, 0), 1), 1, sc_if(sc_num_eq(YEAR, 1900), 1, 0)));
  let var_34 = sc_if(sc_num_eq(sc_if(sc_num_eq((YEAR % 4), 0), 1, 0), 0), 0, var_36);
  return var_34;
}
