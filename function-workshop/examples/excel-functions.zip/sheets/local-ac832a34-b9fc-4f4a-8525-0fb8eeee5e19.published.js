function SLN(COST, SALVAGE, LIFE) {
  return ((COST - SALVAGE) / LIFE);
}
