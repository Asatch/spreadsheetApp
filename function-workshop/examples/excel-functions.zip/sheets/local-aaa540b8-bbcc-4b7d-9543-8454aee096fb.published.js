function MOD(NUMBER, DIVISOR) {
  return (NUMBER - (Math.floor((NUMBER / DIVISOR)) * DIVISOR));
}
