function FISHERINV(Y) {
  return ((Math.exp((2 * Y)) - 1) / (Math.exp((2 * Y)) + 1));
}
