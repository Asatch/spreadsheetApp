function sc_num_eq(a, b) { return (!isFinite(a) || !isFinite(b)) ? NaN : (a === b); }
function sc_if(c, t, f) { return (c === true) ? t : (c === false) ? f : NaN; }

function FV(RATE, NPER, PMT, PV, TYPE) {
  let var_48 = ((-(PMT) * ((((1 + RATE) ** NPER) - 1) / RATE)) * sc_if(sc_num_eq(TYPE, 1), (1 + RATE), 1));
  let var_54 = ((-(PV) * ((1 + RATE) ** NPER)) + var_48);
  return var_54;
}
