function TIME(HOUR, MINUTE, SECOND) {
  return (((HOUR / 24) + (MINUTE / 1440)) + (SECOND / 86400));
}
