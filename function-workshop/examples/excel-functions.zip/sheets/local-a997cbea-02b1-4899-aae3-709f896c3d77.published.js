function sc_num_lte(a, b) { return (!isFinite(a) || !isFinite(b)) ? NaN : (a <= b); }
function sc_if(c, t, f) { return (c === true) ? t : (c === false) ? f : NaN; }

function NORMSINV(P) {
  let var_29 = ((-2 * Math.log(sc_if(sc_num_lte(P, 0.5), P, (1 - P)))) ** 0.5);
  let var_40 = (var_29 ** 2);
  let var_53 = (((2.515517 + (0.802853 * var_29)) + (0.010328 * var_40)) / (((1 + (1.432788 * var_29)) + (0.189269 * var_40)) + (0.001308 * (var_29 ** 3))));
  let var_52 = (var_29 - var_53);
  return sc_if(sc_num_lte(P, 0.5), -(var_52), var_52);
}
