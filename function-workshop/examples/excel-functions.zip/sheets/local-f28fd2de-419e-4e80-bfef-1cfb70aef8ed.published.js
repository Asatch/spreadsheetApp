function sc_num_eq(a, b) { return (!isFinite(a) || !isFinite(b)) ? NaN : (a === b); }
function sc_if(c, t, f) { return (c === true) ? t : (c === false) ? f : NaN; }

function NPER(RATE, PMT, PV, FV, TYPE) {
  let var_49 = (((PMT * sc_if(sc_num_eq(TYPE, 1), (1 + RATE), 1)) - (FV * RATE)) / ((PMT * sc_if(sc_num_eq(TYPE, 1), (1 + RATE), 1)) + (PV * RATE)));
  let var_52 = Math.log(var_49);
  let var_62 = (var_52 / Math.log((1 + RATE)));
  let var_59 = sc_if(sc_num_eq(RATE, 0), (-((PV + FV)) / PMT), var_62);
  return var_59;
}
