function sc_num_eq(a, b) { return (!isFinite(a) || !isFinite(b)) ? NaN : (a === b); }
function sc_if(c, t, f) { return (c === true) ? t : (c === false) ? f : NaN; }

function IPMT(RATE, PER, NPER, PV, FV, TYPE) {
  let var_41 = ((-(RATE) * ((PV * ((1 + RATE) ** NPER)) + FV)) / ((((1 + RATE) ** NPER) - 1) * sc_if(sc_num_eq(TYPE, 1), (1 + RATE), 1)));
  let var_70 = (var_41 * sc_if(sc_num_eq(RATE, 0), (PER - 1), ((((1 + RATE) ** (PER - 1)) - 1) / RATE)));
  let var_69 = (var_70 * sc_if(sc_num_eq(TYPE, 1), (1 + RATE), 1));
  let var_73 = ((PV * ((1 + RATE) ** (PER - 1))) + var_69);
  let var_77 = (var_73 * RATE);
  return var_77;
}
