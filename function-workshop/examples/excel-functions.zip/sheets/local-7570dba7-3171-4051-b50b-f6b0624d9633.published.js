function sc_num_lte(a, b) { return (!isFinite(a) || !isFinite(b)) ? NaN : (a <= b); }
function sc_if(c, t, f) { return (c === true) ? t : (c === false) ? f : NaN; }
function sc_num_lt(a, b) { return (!isFinite(a) || !isFinite(b)) ? NaN : (a < b); }
function sc_num_eq(a, b) { return (!isFinite(a) || !isFinite(b)) ? NaN : (a === b); }
function sc_num_gt(a, b) { return (!isFinite(a) || !isFinite(b)) ? NaN : (a > b); }

function DAY(SERIAL) {
  let var_238 = Math.floor(((((SERIAL + 109571.75) / 365.2425) - 300) + 1900));
  let var_78 = ((Math.floor(((var_238 - 1) / 4)) - Math.floor(((var_238 - 1) / 100))) + Math.floor(((var_238 - 1) / 400)));
  let var_76 = (var_78 - 459);
  let var_73 = sc_if(sc_num_lte(var_238, 1900), 0, var_76);
  let var_71 = (((var_238 - 1900) * 365) + var_73);
  let var_70 = (var_71 + 1);
  let var_91 = (SERIAL - var_70);
  let var_90 = (var_91 + 1);
  let var_95 = sc_num_lt(var_90, 1);
  let var_116 = (sc_if(var_95, (var_238 - 1), var_238) - 1);
  let var_229 = sc_if(sc_num_eq(sc_if(sc_num_eq((sc_if(var_95, (var_238 - 1), var_238) % 400), 0), 1, 0), 1), 1, sc_if(sc_num_eq(sc_if(var_95, (var_238 - 1), var_238), 1900), 1, 0));
  let var_105 = (((Math.floor((var_116 / 4)) - Math.floor((var_116 / 100))) + Math.floor((var_116 / 400))) - 459);
  let var_227 = sc_if(sc_num_eq(sc_if(sc_num_eq((sc_if(var_95, (var_238 - 1), var_238) % 100), 0), 1, 0), 0), 1, var_229);
  let var_102 = sc_if(sc_num_lte(sc_if(var_95, (var_238 - 1), var_238), 1900), 0, var_105);
  let var_225 = sc_if(sc_num_eq(sc_if(sc_num_eq((sc_if(var_95, (var_238 - 1), var_238) % 4), 0), 1, 0), 0), 0, var_227);
  let var_100 = (((sc_if(var_95, (var_238 - 1), var_238) - 1900) * 365) + var_102);
  let var_99 = (var_100 + 1);
  let var_120 = (SERIAL - var_99);
  let var_119 = (var_120 + 1);
  let var_130 = (var_119 - sc_if(sc_num_gt(var_119, 59), var_225, 0));
  let var_145 = sc_if(sc_num_lte(var_130, 212), 7, sc_if(sc_num_lte(var_130, 243), 8, sc_if(sc_num_lte(var_130, 273), 9, sc_if(sc_num_lte(var_130, 304), 10, sc_if(sc_num_lte(var_130, 334), 11, 12)))));
  let var_143 = sc_if(sc_num_lte(var_130, 181), 6, var_145);
  let var_141 = sc_if(sc_num_lte(var_130, 151), 5, var_143);
  let var_139 = sc_if(sc_num_lte(var_130, 120), 4, var_141);
  let var_137 = sc_if(sc_num_lte(var_130, 90), 3, var_139);
  let var_135 = sc_if(sc_num_lte(var_130, 59), 2, var_137);
  let var_133 = sc_if(sc_num_lte(var_130, 31), 1, var_135);
  let var_170 = sc_if(sc_num_eq(var_133, 7), 181, sc_if(sc_num_eq(var_133, 8), 212, sc_if(sc_num_eq(var_133, 9), 243, sc_if(sc_num_eq(var_133, 10), 273, sc_if(sc_num_eq(var_133, 11), 304, 334)))));
  let var_168 = sc_if(sc_num_eq(var_133, 6), 151, var_170);
  let var_166 = sc_if(sc_num_eq(var_133, 5), 120, var_168);
  let var_188 = (var_119 - sc_if(sc_num_eq(var_133, 1), 0, sc_if(sc_num_eq(var_133, 2), 31, sc_if(sc_num_eq(var_133, 3), 59, sc_if(sc_num_eq(var_133, 4), 90, var_166)))));
  let var_187 = (var_188 - sc_if(sc_num_gt(var_133, 2), var_225, 0));
  return var_187;
}
