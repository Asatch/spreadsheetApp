function FISHER(X) {
  return (0.5 * Math.log(((1 + X) / (1 - X))));
}
