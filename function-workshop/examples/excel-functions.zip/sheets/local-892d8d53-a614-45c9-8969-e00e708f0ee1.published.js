function HOUR(SERIAL) {
  return Math.floor(((SERIAL % 1) * 24));
}
