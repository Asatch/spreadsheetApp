function sc_num_lte(a, b) { return (!isFinite(a) || !isFinite(b)) ? NaN : (a <= b); }
function sc_if(c, t, f) { return (c === true) ? t : (c === false) ? f : NaN; }
function sc_num_lt(a, b) { return (!isFinite(a) || !isFinite(b)) ? NaN : (a < b); }
function sc_num_eq(a, b) { return (!isFinite(a) || !isFinite(b)) ? NaN : (a === b); }
function sc_num_gt(a, b) { return (!isFinite(a) || !isFinite(b)) ? NaN : (a > b); }
function sc_num_gte(a, b) { return (!isFinite(a) || !isFinite(b)) ? NaN : (a >= b); }

function DAYS360(START_DATE, END_DATE, METHOD) {
  let var_345 = Math.floor(((((END_DATE + 109571.75) / 365.2425) - 300) + 1900));
  let var_331 = Math.floor(((((START_DATE + 109571.75) / 365.2425) - 300) + 1900));
  let var_155 = ((Math.floor(((var_345 - 1) / 4)) - Math.floor(((var_345 - 1) / 100))) + Math.floor(((var_345 - 1) / 400)));
  let var_34 = ((Math.floor(((var_331 - 1) / 4)) - Math.floor(((var_331 - 1) / 100))) + Math.floor(((var_331 - 1) / 400)));
  let var_153 = (var_155 - 459);
  let var_32 = (var_34 - 459);
  let var_150 = sc_if(sc_num_lte(var_345, 1900), 0, var_153);
  let var_29 = sc_if(sc_num_lte(var_331, 1900), 0, var_32);
  let var_148 = (((var_345 - 1900) * 365) + var_150);
  let var_27 = (((var_331 - 1900) * 365) + var_29);
  let var_147 = (var_148 + 1);
  let var_26 = (var_27 + 1);
  let var_169 = (END_DATE - var_147);
  let var_48 = (START_DATE - var_26);
  let var_168 = (var_169 + 1);
  let var_47 = (var_48 + 1);
  let var_167 = sc_num_lt(var_168, 1);
  let var_46 = sc_num_lt(var_47, 1);
  let var_166 = sc_if(var_167, (var_345 - 1), var_345);
  let var_45 = sc_if(var_46, (var_331 - 1), var_331);
  let var_188 = (var_166 - 1);
  let var_67 = (var_45 - 1);
  let var_195 = sc_if(sc_num_eq((var_166 % 400), 0), 1, sc_if(sc_num_eq((var_166 % 100), 0), 0, sc_if(sc_num_eq((var_166 % 4), 0), 1, 0)));
  let var_74 = sc_if(sc_num_eq((var_45 % 400), 0), 1, sc_if(sc_num_eq((var_45 % 100), 0), 0, sc_if(sc_num_eq((var_45 % 4), 0), 1, 0)));
  let var_177 = (((Math.floor((var_188 / 4)) - Math.floor((var_188 / 100))) + Math.floor((var_188 / 400))) - 459);
  let var_193 = sc_if(sc_num_eq(var_166, 1900), 1, var_195);
  let var_56 = (((Math.floor((var_67 / 4)) - Math.floor((var_67 / 100))) + Math.floor((var_67 / 400))) - 459);
  let var_72 = sc_if(sc_num_eq(var_45, 1900), 1, var_74);
  let var_174 = sc_if(sc_num_lte(var_166, 1900), 0, var_177);
  let var_53 = sc_if(sc_num_lte(var_45, 1900), 0, var_56);
  let var_172 = (((var_166 - 1900) * 365) + var_174);
  let var_51 = (((var_45 - 1900) * 365) + var_53);
  let var_171 = (var_172 + 1);
  let var_50 = (var_51 + 1);
  let var_191 = (END_DATE - var_171);
  let var_70 = (START_DATE - var_50);
  let var_190 = (var_191 + 1);
  let var_69 = (var_70 + 1);
  let var_205 = (var_190 - sc_if(sc_num_gt(var_190, 59), var_193, 0));
  let var_84 = (var_69 - sc_if(sc_num_gt(var_69, 59), var_72, 0));
  let var_221 = sc_if(sc_num_lte(var_205, 212), 7, sc_if(sc_num_lte(var_205, 243), 8, sc_if(sc_num_lte(var_205, 273), 9, sc_if(sc_num_lte(var_205, 304), 10, sc_if(sc_num_lte(var_205, 334), 11, 12)))));
  let var_100 = sc_if(sc_num_lte(var_84, 212), 7, sc_if(sc_num_lte(var_84, 243), 8, sc_if(sc_num_lte(var_84, 273), 9, sc_if(sc_num_lte(var_84, 304), 10, sc_if(sc_num_lte(var_84, 334), 11, 12)))));
  let var_219 = sc_if(sc_num_lte(var_205, 181), 6, var_221);
  let var_98 = sc_if(sc_num_lte(var_84, 181), 6, var_100);
  let var_217 = sc_if(sc_num_lte(var_205, 151), 5, var_219);
  let var_96 = sc_if(sc_num_lte(var_84, 151), 5, var_98);
  let var_215 = sc_if(sc_num_lte(var_205, 120), 4, var_217);
  let var_94 = sc_if(sc_num_lte(var_84, 120), 4, var_96);
  let var_213 = sc_if(sc_num_lte(var_205, 90), 3, var_215);
  let var_92 = sc_if(sc_num_lte(var_84, 90), 3, var_94);
  let var_211 = sc_if(sc_num_lte(var_205, 59), 2, var_213);
  let var_90 = sc_if(sc_num_lte(var_84, 59), 2, var_92);
  let var_209 = sc_if(sc_num_lte(var_205, 31), 1, var_211);
  let var_88 = sc_if(sc_num_lte(var_84, 31), 1, var_90);
  let var_244 = sc_if(sc_num_eq(var_209, 7), 181, sc_if(sc_num_eq(var_209, 8), 212, sc_if(sc_num_eq(var_209, 9), 243, sc_if(sc_num_eq(var_209, 10), 273, sc_if(sc_num_eq(var_209, 11), 304, 334)))));
  let var_123 = sc_if(sc_num_eq(var_88, 7), 181, sc_if(sc_num_eq(var_88, 8), 212, sc_if(sc_num_eq(var_88, 9), 243, sc_if(sc_num_eq(var_88, 10), 273, sc_if(sc_num_eq(var_88, 11), 304, 334)))));
  let var_242 = sc_if(sc_num_eq(var_209, 6), 151, var_244);
  let var_121 = sc_if(sc_num_eq(var_88, 6), 151, var_123);
  let var_240 = sc_if(sc_num_eq(var_209, 5), 120, var_242);
  let var_119 = sc_if(sc_num_eq(var_88, 5), 120, var_121);
  let var_238 = sc_if(sc_num_eq(var_209, 4), 90, var_240);
  let var_117 = sc_if(sc_num_eq(var_88, 4), 90, var_119);
  let var_236 = sc_if(sc_num_eq(var_209, 3), 59, var_238);
  let var_115 = sc_if(sc_num_eq(var_88, 3), 59, var_117);
  let var_234 = sc_if(sc_num_eq(var_209, 2), 31, var_236);
  let var_113 = sc_if(sc_num_eq(var_88, 2), 31, var_115);
  let var_232 = sc_if(sc_num_eq(var_209, 1), 0, var_234);
  let var_111 = sc_if(sc_num_eq(var_88, 1), 0, var_113);
  let var_256 = (var_190 - var_232);
  let var_135 = (var_69 - var_111);
  let var_255 = (var_256 - sc_if(sc_num_gt(var_209, 2), var_193, 0));
  let var_134 = (var_135 - sc_if(sc_num_gt(var_88, 2), var_72, 0));
  let var_275 = sc_num_eq(var_255, 31);
  let var_287 = (sc_if(sc_num_eq(METHOD, 1), sc_if(var_275, 30, var_255), sc_if(var_275, sc_if(sc_num_gte(sc_if(sc_num_eq(var_134, 31), 30, var_134), 30), 30, var_255), var_255)) - sc_if(sc_num_eq(var_134, 31), 30, var_134));
  let var_290 = ((((var_166 - var_45) * 360) + ((var_209 - var_88) * 30)) + var_287);
  return var_290;
}
