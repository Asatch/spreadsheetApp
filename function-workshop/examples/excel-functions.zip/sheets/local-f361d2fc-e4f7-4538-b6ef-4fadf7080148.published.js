function sc_num_eq(a, b) { return (!isFinite(a) || !isFinite(b)) ? NaN : (a === b); }
function sc_if(c, t, f) { return (c === true) ? t : (c === false) ? f : NaN; }
function sc_num_lte(a, b) { return (!isFinite(a) || !isFinite(b)) ? NaN : (a <= b); }
function sc_num_gt(a, b) { return (!isFinite(a) || !isFinite(b)) ? NaN : (a > b); }

function DATE(YEAR, MONTH, DAY) {
  let var_56 = (((MONTH - 1) % 12) + 1);
  let var_53 = (YEAR + Math.floor(((MONTH - 1) / 12)));
  let var_103 = (var_53 - 1);
  let var_73 = sc_if(sc_num_eq(var_56, 7), 181, sc_if(sc_num_eq(var_56, 8), 212, sc_if(sc_num_eq(var_56, 9), 243, sc_if(sc_num_eq(var_56, 10), 273, sc_if(sc_num_eq(var_56, 11), 304, 334)))));
  let var_108 = (((Math.floor((var_103 / 4)) - Math.floor((var_103 / 100))) + Math.floor((var_103 / 400))) - 459);
  let var_158 = sc_if(sc_num_eq(sc_if(sc_num_eq((var_53 % 100), 0), 1, 0), 0), 1, sc_if(sc_num_eq(sc_if(sc_num_eq((var_53 % 400), 0), 1, 0), 1), 1, sc_if(sc_num_eq(var_53, 1900), 1, 0)));
  let var_71 = sc_if(sc_num_eq(var_56, 6), 151, var_73);
  let var_106 = sc_if(sc_num_lte(var_53, 1900), 0, var_108);
  let var_156 = sc_if(sc_num_eq(sc_if(sc_num_eq((var_53 % 4), 0), 1, 0), 0), 0, var_158);
  let var_69 = sc_if(sc_num_eq(var_56, 5), 120, var_71);
  let var_119 = (((var_53 - 1900) * 365) + var_106);
  let var_88 = sc_if(sc_num_gt(var_56, 2), var_156, 0);
  let var_67 = sc_if(sc_num_eq(var_56, 4), 90, var_69);
  let var_65 = sc_if(sc_num_eq(var_56, 3), 59, var_67);
  let var_63 = sc_if(sc_num_eq(var_56, 2), 31, var_65);
  let var_123 = (var_119 + ((sc_if(sc_num_eq(var_56, 1), 0, var_63) + var_88) + DAY));
  return var_123;
}
