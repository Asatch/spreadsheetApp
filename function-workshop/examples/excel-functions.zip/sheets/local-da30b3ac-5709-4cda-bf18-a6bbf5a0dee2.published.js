function sc_num_eq(a, b) { return (!isFinite(a) || !isFinite(b)) ? NaN : (a === b); }
function sc_if(c, t, f) { return (c === true) ? t : (c === false) ? f : NaN; }

function PPMT(RATE, PER, NPER, PV, FV, TYPE) {
  let var_40 = ((-(RATE) * ((PV * ((1 + RATE) ** NPER)) + FV)) / ((((1 + RATE) ** NPER) - 1) * sc_if(sc_num_eq(TYPE, 1), (1 + RATE), 1)));
  let var_61 = (var_40 * sc_if(sc_num_eq(RATE, 0), (PER - 1), ((((1 + RATE) ** (PER - 1)) - 1) / RATE)));
  let var_60 = (var_61 * sc_if(sc_num_eq(TYPE, 1), (1 + RATE), 1));
  let var_58 = ((PV * ((1 + RATE) ** (PER - 1))) + var_60);
  let var_69 = (var_58 * RATE);
  let var_73 = (var_40 + var_69);
  return var_73;
}
