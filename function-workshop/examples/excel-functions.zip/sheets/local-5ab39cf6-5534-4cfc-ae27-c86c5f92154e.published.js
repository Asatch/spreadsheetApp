function MINUTE(SERIAL) {
  return Math.floor(((((SERIAL % 1) * 24) % 1) * 60));
}
