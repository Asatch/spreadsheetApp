function sc_num_lt(a, b) { return (!isFinite(a) || !isFinite(b)) ? NaN : (a < b); }
function sc_if(c, t, f) { return (c === true) ? t : (c === false) ? f : NaN; }

function EVEN(NUMBER) {
  let var_17 = -(Math.floor(-((sc_if(sc_num_lt(NUMBER, 0), -(NUMBER), NUMBER) / 2))));
  let var_22 = (var_17 * 2);
  let var_31 = (sc_if(sc_num_lt(NUMBER, 0), -1, 1) * var_22);
  return var_31;
}
