function PROGRESSIVE_TAX(INCOME) {
  let var_41 = (Math.max(...[0, (Math.min(...[INCOME, 394600]) - 206700)]) * 0.24);
  let var_49 = (Math.max(...[0, (Math.min(...[INCOME, 501050]) - 394600)]) * 0.32);
  let var_57 = (Math.max(...[0, (Math.min(...[INCOME, 751600]) - 501050)]) * 0.35);
  let var_67 = [(Math.min(...[INCOME, 23850]) * 0.1), (Math.max(...[0, (Math.min(...[INCOME, 96950]) - 23850)]) * 0.12), (Math.max(...[0, (Math.min(...[INCOME, 206700]) - 96950)]) * 0.22), var_41, var_49, var_57, (Math.max(...[0, (INCOME - 751600)]) * 0.37)];
  let var_66 = var_67.reduce((a, b) => a + b, 0);
  return var_66;
}
