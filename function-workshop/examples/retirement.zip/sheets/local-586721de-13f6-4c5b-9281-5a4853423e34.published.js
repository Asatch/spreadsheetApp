function sc_num_gte(a, b) { return (!isFinite(a) || !isFinite(b)) ? NaN : (a >= b); }
function sc_if(c, t, f) { return (c === true) ? t : (c === false) ? f : NaN; }
function sc_num_gt(a, b) { return (!isFinite(a) || !isFinite(b)) ? NaN : (a > b); }

function CALCULATE_RMD(BALANCE, AGE) {
  let var_167 = sc_if(sc_num_gt(sc_if(sc_num_gte(72, AGE), 27.4, 0), 0), sc_if(sc_num_gte(72, AGE), 27.4, 0), sc_if(sc_num_gte(73, AGE), 26.5, 0));
  let var_173 = sc_if(sc_num_gt(sc_if(sc_num_gt(var_167, 0), var_167, sc_if(sc_num_gte(74, AGE), 25.5, 0)), 0), sc_if(sc_num_gt(var_167, 0), var_167, sc_if(sc_num_gte(74, AGE), 25.5, 0)), sc_if(sc_num_gte(75, AGE), 24.6, 0));
  let var_179 = sc_if(sc_num_gt(sc_if(sc_num_gt(var_173, 0), var_173, sc_if(sc_num_gte(76, AGE), 23.7, 0)), 0), sc_if(sc_num_gt(var_173, 0), var_173, sc_if(sc_num_gte(76, AGE), 23.7, 0)), sc_if(sc_num_gte(77, AGE), 22.9, 0));
  let var_185 = sc_if(sc_num_gt(sc_if(sc_num_gt(var_179, 0), var_179, sc_if(sc_num_gte(78, AGE), 22, 0)), 0), sc_if(sc_num_gt(var_179, 0), var_179, sc_if(sc_num_gte(78, AGE), 22, 0)), sc_if(sc_num_gte(79, AGE), 21.1, 0));
  let var_191 = sc_if(sc_num_gt(sc_if(sc_num_gt(var_185, 0), var_185, sc_if(sc_num_gte(80, AGE), 20.2, 0)), 0), sc_if(sc_num_gt(var_185, 0), var_185, sc_if(sc_num_gte(80, AGE), 20.2, 0)), sc_if(sc_num_gte(81, AGE), 19.4, 0));
  let var_197 = sc_if(sc_num_gt(sc_if(sc_num_gt(var_191, 0), var_191, sc_if(sc_num_gte(82, AGE), 18.5, 0)), 0), sc_if(sc_num_gt(var_191, 0), var_191, sc_if(sc_num_gte(82, AGE), 18.5, 0)), sc_if(sc_num_gte(83, AGE), 17.7, 0));
  let var_203 = sc_if(sc_num_gt(sc_if(sc_num_gt(var_197, 0), var_197, sc_if(sc_num_gte(84, AGE), 16.8, 0)), 0), sc_if(sc_num_gt(var_197, 0), var_197, sc_if(sc_num_gte(84, AGE), 16.8, 0)), sc_if(sc_num_gte(85, AGE), 16, 0));
  let var_209 = sc_if(sc_num_gt(sc_if(sc_num_gt(var_203, 0), var_203, sc_if(sc_num_gte(86, AGE), 15.2, 0)), 0), sc_if(sc_num_gt(var_203, 0), var_203, sc_if(sc_num_gte(86, AGE), 15.2, 0)), sc_if(sc_num_gte(87, AGE), 14.4, 0));
  let var_215 = sc_if(sc_num_gt(sc_if(sc_num_gt(var_209, 0), var_209, sc_if(sc_num_gte(88, AGE), 13.7, 0)), 0), sc_if(sc_num_gt(var_209, 0), var_209, sc_if(sc_num_gte(88, AGE), 13.7, 0)), sc_if(sc_num_gte(89, AGE), 12.9, 0));
  let var_221 = sc_if(sc_num_gt(sc_if(sc_num_gt(var_215, 0), var_215, sc_if(sc_num_gte(90, AGE), 12.2, 0)), 0), sc_if(sc_num_gt(var_215, 0), var_215, sc_if(sc_num_gte(90, AGE), 12.2, 0)), sc_if(sc_num_gte(91, AGE), 11.5, 0));
  let var_227 = sc_if(sc_num_gt(sc_if(sc_num_gt(var_221, 0), var_221, sc_if(sc_num_gte(92, AGE), 10.8, 0)), 0), sc_if(sc_num_gt(var_221, 0), var_221, sc_if(sc_num_gte(92, AGE), 10.8, 0)), sc_if(sc_num_gte(93, AGE), 10.1, 0));
  let var_233 = sc_if(sc_num_gt(sc_if(sc_num_gt(var_227, 0), var_227, sc_if(sc_num_gte(94, AGE), 9.5, 0)), 0), sc_if(sc_num_gt(var_227, 0), var_227, sc_if(sc_num_gte(94, AGE), 9.5, 0)), sc_if(sc_num_gte(95, AGE), 8.9, 0));
  let var_239 = sc_if(sc_num_gt(sc_if(sc_num_gt(var_233, 0), var_233, sc_if(sc_num_gte(96, AGE), 8.4, 0)), 0), sc_if(sc_num_gt(var_233, 0), var_233, sc_if(sc_num_gte(96, AGE), 8.4, 0)), sc_if(sc_num_gte(97, AGE), 7.8, 0));
  let var_245 = sc_if(sc_num_gt(sc_if(sc_num_gt(var_239, 0), var_239, sc_if(sc_num_gte(98, AGE), 7.3, 0)), 0), sc_if(sc_num_gt(var_239, 0), var_239, sc_if(sc_num_gte(98, AGE), 7.3, 0)), sc_if(sc_num_gte(99, AGE), 6.8, 0));
  let var_251 = sc_if(sc_num_gt(sc_if(sc_num_gt(var_245, 0), var_245, sc_if(sc_num_gte(100, AGE), 6.4, 0)), 0), sc_if(sc_num_gt(var_245, 0), var_245, sc_if(sc_num_gte(100, AGE), 6.4, 0)), sc_if(sc_num_gte(101, AGE), 6, 0));
  let var_257 = sc_if(sc_num_gt(sc_if(sc_num_gt(var_251, 0), var_251, sc_if(sc_num_gte(102, AGE), 5.6, 0)), 0), sc_if(sc_num_gt(var_251, 0), var_251, sc_if(sc_num_gte(102, AGE), 5.6, 0)), sc_if(sc_num_gte(103, AGE), 5.2, 0));
  let var_263 = sc_if(sc_num_gt(sc_if(sc_num_gt(var_257, 0), var_257, sc_if(sc_num_gte(104, AGE), 4.9, 0)), 0), sc_if(sc_num_gt(var_257, 0), var_257, sc_if(sc_num_gte(104, AGE), 4.9, 0)), sc_if(sc_num_gte(105, AGE), 4.6, 0));
  let var_269 = sc_if(sc_num_gt(sc_if(sc_num_gt(var_263, 0), var_263, sc_if(sc_num_gte(106, AGE), 4.3, 0)), 0), sc_if(sc_num_gt(var_263, 0), var_263, sc_if(sc_num_gte(106, AGE), 4.3, 0)), sc_if(sc_num_gte(107, AGE), 4.1, 0));
  let var_275 = sc_if(sc_num_gt(sc_if(sc_num_gt(var_269, 0), var_269, sc_if(sc_num_gte(108, AGE), 3.9, 0)), 0), sc_if(sc_num_gt(var_269, 0), var_269, sc_if(sc_num_gte(108, AGE), 3.9, 0)), sc_if(sc_num_gte(109, AGE), 3.7, 0));
  let var_281 = sc_if(sc_num_gt(sc_if(sc_num_gt(var_275, 0), var_275, sc_if(sc_num_gte(110, AGE), 3.5, 0)), 0), sc_if(sc_num_gt(var_275, 0), var_275, sc_if(sc_num_gte(110, AGE), 3.5, 0)), sc_if(sc_num_gte(111, AGE), 3.4, 0));
  let var_287 = sc_if(sc_num_gt(sc_if(sc_num_gt(var_281, 0), var_281, sc_if(sc_num_gte(112, AGE), 3.3, 0)), 0), sc_if(sc_num_gt(var_281, 0), var_281, sc_if(sc_num_gte(112, AGE), 3.3, 0)), sc_if(sc_num_gte(113, AGE), 3.1, 0));
  let var_293 = sc_if(sc_num_gt(sc_if(sc_num_gt(var_287, 0), var_287, sc_if(sc_num_gte(114, AGE), 3, 0)), 0), sc_if(sc_num_gt(var_287, 0), var_287, sc_if(sc_num_gte(114, AGE), 3, 0)), sc_if(sc_num_gte(115, AGE), 2.9, 0));
  let var_299 = sc_if(sc_num_gt(sc_if(sc_num_gt(var_293, 0), var_293, sc_if(sc_num_gte(116, AGE), 2.8, 0)), 0), sc_if(sc_num_gt(var_293, 0), var_293, sc_if(sc_num_gte(116, AGE), 2.8, 0)), sc_if(sc_num_gte(117, AGE), 2.7, 0));
  let var_305 = sc_if(sc_num_gt(sc_if(sc_num_gt(var_299, 0), var_299, sc_if(sc_num_gte(118, AGE), 2.5, 0)), 0), sc_if(sc_num_gt(var_299, 0), var_299, sc_if(sc_num_gte(118, AGE), 2.5, 0)), sc_if(sc_num_gte(119, AGE), 2.3, 0));
  return sc_if(sc_num_gte(AGE, 75), (BALANCE / sc_if(sc_num_gt(var_305, 0), var_305, sc_if(sc_num_gte(120, AGE), 2, 0))), 0);
}
