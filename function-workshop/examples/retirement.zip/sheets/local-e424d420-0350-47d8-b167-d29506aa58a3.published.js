function sc_num_eq(a, b) { return (!isFinite(a) || !isFinite(b)) ? NaN : (a === b); }
function sc_if(c, t, f) { return (c === true) ? t : (c === false) ? f : NaN; }

function WITHDRAW_TAXABLE(BALANCE, SHORTFALL, BASIS) {
  let var_28 = (0.15 * sc_if(sc_num_eq(BALANCE, 0), 0, ((BALANCE - BASIS) / BALANCE)));
  let var_39 = sc_if(sc_num_eq(BALANCE, 0), 0, Math.min(...[sc_if(sc_num_eq(var_28, 1), SHORTFALL, (SHORTFALL / (1 - var_28))), BALANCE]));
  return { WITHDRAWAL: var_39, TAX: (var_39 * var_28), REMAINING_SHORTFALL: Math.max(...[0, (SHORTFALL - (var_39 - (var_39 * var_28)))]), BASIS_REDUCTION: sc_if(sc_num_eq(BALANCE, 0), 0, sc_if(sc_num_eq(var_39, BALANCE), BASIS, (var_39 * (BASIS / BALANCE)))) };
}
