function sc_num_gte(a, b) { return (!isFinite(a) || !isFinite(b)) ? NaN : (a >= b); }
function sc_num_lte(a, b) { return (!isFinite(a) || !isFinite(b)) ? NaN : (a <= b); }
function sc_and(arr) { let n = false; for (const v of arr) { if (v === false) return false; if (v !== true) n = true; } return n ? NaN : true; }
function sc_if(c, t, f) { return (c === true) ? t : (c === false) ? f : NaN; }

function CUSTOM_ACCOUNT_DIST(BALANCE, YEAR) {
  return sc_if(sc_and([sc_num_gte(YEAR, 1), sc_num_lte(YEAR, 10)]), (BALANCE / ((10 - YEAR) + 1)), 0);
}
