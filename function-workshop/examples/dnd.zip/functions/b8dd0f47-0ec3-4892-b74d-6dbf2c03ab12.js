function LOG(X, BASE) {
  return (Math.log(X) / Math.log(BASE));
}
