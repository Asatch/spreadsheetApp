function HP_CALCULATOR(LEVEL, HIT_DIE, CON_MOD) {
  return ((HIT_DIE + ((LEVEL - 1) * ((HIT_DIE / 2) + 1))) + (CON_MOD * LEVEL));
}
