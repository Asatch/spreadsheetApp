function sc_num_eq(a, b) { return (!isFinite(a) || !isFinite(b)) ? NaN : (a === b); }
function sc_if(c, t, f) { return (c === true) ? t : (c === false) ? f : NaN; }

function AC_CALCULATOR(ARMOR_TYPE, ARMOR_BASE, DEX_MOD, SHIELD, MAGIC_BONUS, OTHER_BONUS) {
  let var_50 = ((ARMOR_BASE + sc_if(sc_num_eq(ARMOR_TYPE, 3), 0, sc_if(sc_num_eq(ARMOR_TYPE, 2), Math.min(...[DEX_MOD, 2]), DEX_MOD))) + (((SHIELD * 2) + MAGIC_BONUS) + OTHER_BONUS));
  return { FINAL_AC: var_50, BASE_AC: (ARMOR_BASE + sc_if(sc_num_eq(ARMOR_TYPE, 3), 0, sc_if(sc_num_eq(ARMOR_TYPE, 2), Math.min(...[DEX_MOD, 2]), DEX_MOD))), DEX_CONTRIBUTION: sc_if(sc_num_eq(ARMOR_TYPE, 3), 0, sc_if(sc_num_eq(ARMOR_TYPE, 2), Math.min(...[DEX_MOD, 2]), DEX_MOD)), SHIELD_BONUS: (SHIELD * 2) };
}
