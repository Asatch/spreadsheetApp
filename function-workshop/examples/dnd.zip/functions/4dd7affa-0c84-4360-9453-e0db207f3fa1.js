function LOG10(X) {
  return (Math.log(X) / 2.302585092994046);
}
