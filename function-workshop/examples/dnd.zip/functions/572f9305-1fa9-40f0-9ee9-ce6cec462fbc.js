function PROFICIENCY_BONUS(LEVEL) {
  return (Math.floor(((LEVEL - 1) / 4)) + 2);
}
