function INT(NUMBER) {
  return Math.floor(NUMBER);
}
