function DPR_CALCULATOR(ATTACK_BONUS, TARGET_AC, DIE_SIZE, DAMAGE_BONUS, NUM_ATTACKS, CRIT_RANGE, ADV_MODE) {
  let var_58 = Math.max(0, Math.min(1, ((21 - CRIT_RANGE) / 20)));
  let var_40 = Math.max(0.05, Math.min(0.95, (((21 + ATTACK_BONUS) - TARGET_AC) / 20)));
  let var_67 = ((ADV_MODE === 1) ? (1 - ((1 - var_58) ** 2)) : ((ADV_MODE === 2) ? (var_58 ** 2) : var_58));
  let var_84 = (((ADV_MODE === 1) ? (1 - ((1 - var_40) ** 2)) : ((ADV_MODE === 2) ? (var_40 ** 2) : var_40)) - var_67);
  let var_86 = (var_84 * (((DIE_SIZE + 1) / 2) + DAMAGE_BONUS));
  let var_88 = (var_86 + (var_67 * ((2 * ((DIE_SIZE + 1) / 2)) + DAMAGE_BONUS)));
  let var_91 = (var_88 * NUM_ATTACKS);
  return { DPR: var_91, HIT_CHANCE: ((ADV_MODE === 1) ? (1 - ((1 - var_40) ** 2)) : ((ADV_MODE === 2) ? (var_40 ** 2) : var_40)), CRIT_CHANCE: var_67, DAMAGE_PER_HIT: (((DIE_SIZE + 1) / 2) + DAMAGE_BONUS), DAMAGE_PER_CRIT: ((2 * ((DIE_SIZE + 1) / 2)) + DAMAGE_BONUS) };
}
