function ATTACK_RESOLVER(D20_ROLL, ATTACK_BONUS, TARGET_AC, DAMAGE_ROLL, DAMAGE_BONUS, CRIT_RANGE) {
  let var_47 = ((((D20_ROLL === 1) ? 1 : 0) === 1) ? 0 : ([(((D20_ROLL >= CRIT_RANGE) ? 1 : 0) === 1), ((D20_ROLL + ATTACK_BONUS) >= TARGET_AC)].some(Boolean) ? 1 : 0));
  let var_59 = (var_47 === 0);
  let var_61 = (var_59 ? 0 : ((((D20_ROLL >= CRIT_RANGE) ? 1 : 0) === 1) ? ((2 * DAMAGE_ROLL) + DAMAGE_BONUS) : (DAMAGE_ROLL + DAMAGE_BONUS)));
  return { DAMAGE: var_61, IS_HIT: var_47, IS_CRIT: ((D20_ROLL >= CRIT_RANGE) ? 1 : 0) };
}
