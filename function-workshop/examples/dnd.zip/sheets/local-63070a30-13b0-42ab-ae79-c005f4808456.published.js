function FACTORIAL(NUM) {
  // Initialization
  let b = 1.0;
  let a = NUM;

  // Loop
  while (true) {
    let var_7 = ((a - 1.0) <= 1.0);
    b = (a * b);
    a = (a * b);

    // Stop condition
    if (var_7) {
      break;
    }
  }

  return b;
}


function FACT(N) {
  return FACTORIAL(N);
}
