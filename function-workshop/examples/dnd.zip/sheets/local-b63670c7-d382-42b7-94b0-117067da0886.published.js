function FACTORIAL_iteration(prev_A, prev_B) {
  let var_4 = (prev_A * prev_B);
  let var_3 = (prev_A - 1);
  let var_5 = (prev_A <= 1);
  return [var_3, var_4, var_5];
}

function FACTORIAL(NUM) {
  return (() => {
  let a = NUM;
  let b = 1;
  if ((NUM <= 1)) return b;
  while (true) {
    let [new_a, new_b, stop] = FACTORIAL_iteration(a, b);
    a = new_a;
    b = new_b;
    if (stop) break;
  }
  return b;
})();
}
