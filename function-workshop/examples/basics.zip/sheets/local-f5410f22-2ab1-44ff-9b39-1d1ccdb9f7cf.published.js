function SIMPLE_ADD(A, B) {
  return (A + B);
}
