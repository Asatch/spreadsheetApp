function PLUS5BUTCOOLER(INPUT1) {
  return (5.0 + INPUT1);
}
